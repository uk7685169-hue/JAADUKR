
require('dotenv').config();
const { Pool } = require('pg');
const fs = require('fs').promises;
const path = require('path');

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function restoreBackup(backupFile) {
    try {
        console.log(`📂 Reading backup file: ${backupFile}`);
        const data = await fs.readFile(backupFile, 'utf-8');
        const backup = JSON.parse(data);

        console.log(`📊 Backup contains:`);
        console.log(`  - ${backup.users?.length || 0} users`);
        console.log(`  - ${backup.waifus?.length || 0} waifus`);
        console.log(`  - ${backup.harem?.length || 0} harem entries`);
        console.log(`  - ${backup.roles?.length || 0} roles`);

        // Restore users
        if (backup.users && backup.users.length > 0) {
            console.log('\n👥 Restoring users...');
            for (const user of backup.users) {
                await pool.query(
                    `INSERT INTO users (user_id, username, first_name, berries, daily_streak, weekly_streak, last_daily_claim, last_weekly_claim, last_claim_date, favorite_waifu_id, harem_filter_rarity) 
                     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11) 
                     ON CONFLICT (user_id) DO UPDATE SET 
                     berries = $4, daily_streak = $5, weekly_streak = $6, 
                     last_daily_claim = $7, last_weekly_claim = $8, last_claim_date = $9,
                     favorite_waifu_id = $10, harem_filter_rarity = $11`,
                    [user.user_id, user.username, user.first_name, user.berries, user.daily_streak, 
                     user.weekly_streak, user.last_daily_claim, user.last_weekly_claim, 
                     user.last_claim_date, user.favorite_waifu_id, user.harem_filter_rarity]
                );
            }
            console.log(`✅ Restored ${backup.users.length} users`);
        }

        // Restore waifus
        if (backup.waifus && backup.waifus.length > 0) {
            console.log('\n🎨 Restoring waifus...');
            for (const waifu of backup.waifus) {
                await pool.query(
                    `INSERT INTO waifus (waifu_id, name, anime, rarity, image_file_id, price, is_locked, uploaded_by) 
                     VALUES ($1, $2, $3, $4, $5, $6, $7, $8) 
                     ON CONFLICT (waifu_id) DO UPDATE SET 
                     name = $2, anime = $3, rarity = $4, image_file_id = $5, price = $6, is_locked = $7, uploaded_by = $8`,
                    [waifu.waifu_id, waifu.name, waifu.anime, waifu.rarity, 
                     waifu.image_file_id, waifu.price, waifu.is_locked, waifu.uploaded_by]
                );
            }
            console.log(`✅ Restored ${backup.waifus.length} waifus`);
        }

        // Restore harem
        if (backup.harem && backup.harem.length > 0) {
            console.log('\n💝 Restoring harem...');
            for (const entry of backup.harem) {
                await pool.query(
                    `INSERT INTO harem (user_id, waifu_id, acquired_date) 
                     VALUES ($1, $2, $3) ON CONFLICT DO NOTHING`,
                    [entry.user_id, entry.waifu_id, entry.acquired_date]
                );
            }
            console.log(`✅ Restored ${backup.harem.length} harem entries`);
        }

        // Restore roles
        if (backup.roles && backup.roles.length > 0) {
            console.log('\n🔑 Restoring roles...');
            for (const role of backup.roles) {
                await pool.query(
                    `INSERT INTO roles (user_id, role_type, granted_at) 
                     VALUES ($1, $2, $3) ON CONFLICT DO NOTHING`,
                    [role.user_id, role.role_type, role.granted_at]
                );
            }
            console.log(`✅ Restored ${backup.roles.length} roles`);
        }

        console.log('\n🎉 Backup restoration completed successfully!');
        process.exit(0);
    } catch (error) {
        console.error('❌ Error restoring backup:', error);
        process.exit(1);
    }
}

// Get the latest backup file
async function getLatestBackup() {
    const backupDir = './backups';
    const files = await fs.readdir(backupDir);
    const backupFiles = files.filter(f => f.startsWith('backup_') && f.endsWith('.json'));
    
    if (backupFiles.length === 0) {
        console.error('❌ No backup files found!');
        process.exit(1);
    }

    backupFiles.sort().reverse();
    return path.join(backupDir, backupFiles[0]);
}

// Run restoration
(async () => {
    const latestBackup = await getLatestBackup();
    console.log(`🔄 Starting restoration from: ${latestBackup}\n`);
    await restoreBackup(latestBackup);
})();
